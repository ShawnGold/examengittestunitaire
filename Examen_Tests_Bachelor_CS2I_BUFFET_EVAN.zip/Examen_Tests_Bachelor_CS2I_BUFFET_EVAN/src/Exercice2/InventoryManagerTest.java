package Exercice2;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Classe de test pour InventoryManager.
 */
public class InventoryManagerTest {
    private InventoryManager inventoryManager;

    @Before
    public void setUp() {
        inventoryManager = new InventoryManager();
    }

    /**
     * Teste le cas où le stock est suffisant.
     */
    @Test
    public void testSufficientStock() {
        inventoryManager.addProduct("iphone15promax", 100);
        int availability = inventoryManager.getStockAvailability("iphone15promax");
        assertEquals(100, availability);
    }

    /**
     * Teste le cas où le stock est insuffisant.
     */
    @Test(expected = IllegalArgumentException.class)
    public void testInsufficientStock() {
        inventoryManager.addProduct("ps5", 5);
        inventoryManager.removeProduct("ps5", 10);
    }

    /**
     * Teste le cas où le stock est épuisé.
     */
    @Test
    public void testOutOfStock() {
        inventoryManager.addProduct("rtx4090", 0);
        int availability = inventoryManager.getStockAvailability("rtx4090");
        assertEquals(0, availability);
    }

    /**
     * Teste le cas où le produit n'existe pas dans l'inventaire.
     */
    @Test
    public void testProductNotInInventory() {
        int availability = inventoryManager.getStockAvailability("Fallout4");
        assertEquals(0, availability);
    }
}
