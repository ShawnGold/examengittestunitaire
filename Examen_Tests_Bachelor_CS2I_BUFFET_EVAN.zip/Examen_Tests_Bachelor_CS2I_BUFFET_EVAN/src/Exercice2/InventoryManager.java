package Exercice2;

import java.util.HashMap;
import java.util.Map;

/**
 * Classe InventoryManager.
 */
public class InventoryManager {
    private Map<String, Integer> inventory;

    /**
     * Constructeur d'InventoryManager.
     */
    public InventoryManager() {
        this.inventory = new HashMap<>();
    }

    /**
     * Ajoute un produit à l'inventaire.
     *
     * @param productId L'identifiant du produit.
     * @param quantity La quantité du produit à ajouter.
     */
    public void addProduct(String productId, int quantity) {
        this.inventory.put(productId, quantity);
    }

    /**
     * Retire un produit de l'inventaire.
     *
     * @param productId L'identifiant du produit.
     * @param quantity La quantité du produit à retirer.
     * @throws IllegalArgumentException si le produit n'est pas dans l'inventaire ou si la quantité à retirer est trop grande.
     */
    public void removeProduct(String productId, int quantity) {
        Integer currentQuantity = this.inventory.get(productId);
        if (currentQuantity == null || currentQuantity < quantity) {
            throw new IllegalArgumentException("Quantité trop grande ou produit pas dispo.");
        }
        this.inventory.put(productId, currentQuantity - quantity);
    }

    /**
     * Renvoie la quantité de stock disponible pour un produit donné.
     *
     * @param productId L'identifiant du produit.
     * @return La quantité de stock disponible.
     */
    public int getStockAvailability(String productId) {
        return this.inventory.getOrDefault(productId, 0);
    }
}
