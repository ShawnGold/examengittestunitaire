package Exercice3;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * Classe de tests d'intégration pour Library.
 */
public class LibraryIntegrationTest {

    @Test
    public void testBorrowBook() {
        Library bibliothèque = new Library();
        Book livre = new Book("Le seigneur des annéaux", "Tolkien");
        User utilisateur = new User("Evan");

        // On ajoute le livre dans la bibliothèque
        bibliothèque.addBook(livre);

        // L'utilisateur emprunte le livre à la bibliothèque
        bibliothèque.borrowBook(livre, utilisateur);

        // On vérifie si le livre a été emprunté 
        assertTrue(utilisateur.getBorrowedBooks().contains(livre));
        assertFalse(bibliothèque.getBooks().contains(livre));
    }
}
