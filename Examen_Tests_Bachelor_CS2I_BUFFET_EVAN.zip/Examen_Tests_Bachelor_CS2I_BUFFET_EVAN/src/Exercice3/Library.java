package Exercice3;

import java.util.ArrayList;
import java.util.List;

/**
 * Classe Library.
 */
public class Library {
    private List<Book> books;

    public Library() {
        this.books = new ArrayList<>();
    }

    public void addBook(Book book) {
        this.books.add(book);
    }

    public boolean isBookAvailable(Book book) {
        return this.books.contains(book);
    }

    public void borrowBook(Book book, User user) {
        if (isBookAvailable(book)) {
            this.books.remove(book);
            user.getBorrowedBooks().add(book);
        } else {
            throw new IllegalArgumentException("Le livre n'est pas disponible.");
        }
    }

    public List<Book> getBooks() {
        return books;
    }

    public void setBooks(List<Book> books) {
        this.books = books;
    }
}
