package Exercice1;

/**
 * Classe des employés.
 */

public class Employee {
    String nom;
    String prenom;
    int anneesExperience;
    String niveau;

    public Employee(String nom, String prenom, int anneesExperience, String niveau) {
        this.nom = nom;
        this.prenom = prenom;
        this.anneesExperience = anneesExperience;
        this.niveau = niveau;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getAnneesExperience() {
        return anneesExperience;
    }

    public void setAnneesExperience(int anneesExperience) {
        this.anneesExperience = anneesExperience;
    }

    public String getNiveau() {
        return niveau;
    }

    public void setNiveau(String niveau) {
        this.niveau = niveau;
    }
}
