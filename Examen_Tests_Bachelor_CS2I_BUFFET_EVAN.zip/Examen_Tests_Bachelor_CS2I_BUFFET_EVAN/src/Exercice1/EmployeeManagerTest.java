package Exercice1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class EmployeeManagerTest {
    @Test
    public void testCalculateSalary_Junior_1() {
        EmployeeManager manager = new EmployeeManager();
        Employee employee = new Employee("Frank", "Fort", 1, "Junior");
        assertEquals(21000, manager.calculateSalary(employee), 0.01);
    }

    @Test
    public void testCalculateSalary_Intermediate_5() {
        EmployeeManager manager = new EmployeeManager();
        Employee employee = new Employee("Marc", "Lelouche", 5, "Intermédiaire");
        assertEquals(50000, manager.calculateSalary(employee), 0.01);
    }

    @Test
    public void testCalculateSalary_Senior_10() {
        EmployeeManager manager = new EmployeeManager();
        Employee employee = new Employee("Patrick", "Onlattendpas", 10, "Senior");
        assertEquals(90000, manager.calculateSalary(employee), 0.01);
    }

    @Test
    public void testCalculateSalary_Senior_20() {
        EmployeeManager manager = new EmployeeManager();
        Employee employee = new Employee("Jean", "Jacques", 20, "Senior");
        assertEquals(120000, manager.calculateSalary(employee), 0.01);
    }
    
    
    @Test
    public void testCalculateSalary_Intermediate_40() {
        EmployeeManager manager = new EmployeeManager();
        Employee employee = new Employee("Jesuis", "Panet", 40, "Intermédiaire");
        assertEquals(120000, manager.calculateSalary(employee), 0.01);
    }
}
