package Exercice1;

/**
 * Classe EmployeeManager.
 */
public class EmployeeManager {
    public double calculateSalary(Employee employee) {
        double baseSalary;
        switch (employee.getNiveau()) {
            case "Junior":
                baseSalary = 20000;
                break;
            case "Intermédiaire":
                baseSalary = 40000;
                break;
            case "Senior":
                baseSalary = 60000;
                break;
            default:
                throw new IllegalArgumentException("Niveau invalide");
        }
        return baseSalary * calculateExperienceMultiplier(employee.getAnneesExperience());
    }

    /**
     * Calcule le coefficient d'ancienneté en fonction des années d'expérience.
     *
     * @param anneesExperience Les années d'expérience.
     * @return Le coefficient d'ancienneté.
     */
    public double calculateExperienceMultiplier(int anneesExperience) {
        return 1 + anneesExperience * 0.05;
    }
}

